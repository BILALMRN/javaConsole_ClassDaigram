var class_models_1_1_diagram =
[
    [ "Diagram", "class_models_1_1_diagram.html#aca0039e535074bddb897c42eb141a74a", null ],
    [ "Diagram", "class_models_1_1_diagram.html#a72bfb595daf6ce23951358ca6cb9054a", null ],
    [ "addClass", "class_models_1_1_diagram.html#a10af91c54e9c5b775c43db0391edb7e4", null ],
    [ "addClassIfNotExist", "class_models_1_1_diagram.html#a9371ff2a9d0e19c17eeaec93642182df", null ],
    [ "addRelationship", "class_models_1_1_diagram.html#a4f930faced79e97aff46defce7df4c2a", null ],
    [ "addRelationshipIfNotExist", "class_models_1_1_diagram.html#a6ec69e70f759051eba74fbc5c63cbf33", null ],
    [ "editClass", "class_models_1_1_diagram.html#abf544adf8745628473b5d4c0a77d7c6c", null ],
    [ "editRelationship", "class_models_1_1_diagram.html#af4447acf4d42697ce7dd15647906ea7b", null ],
    [ "getDiagramsName", "class_models_1_1_diagram.html#a2f6841c386e681ca1a1fac6c3c151600", null ],
    [ "getListClass", "class_models_1_1_diagram.html#af17739e9b811d9fa192c41704e3d1722", null ],
    [ "getListRelationships", "class_models_1_1_diagram.html#afed62c52c251902332894071c597744c", null ],
    [ "removeAllClass", "class_models_1_1_diagram.html#a2b74bc025941d5a99ddf8d02c3b33754", null ],
    [ "removeAllRelationship", "class_models_1_1_diagram.html#a96687c73009b6d1a2e075cbb67239503", null ],
    [ "removeClass", "class_models_1_1_diagram.html#ae475c2cc718f3d9c8bbb4607f57a54ac", null ],
    [ "removeRelationship", "class_models_1_1_diagram.html#aa43c7f3d490bc178681dc0e90d4dac9d", null ],
    [ "setDiagramsName", "class_models_1_1_diagram.html#a43a9920931aed21d00198862c34fafbd", null ],
    [ "setListClass", "class_models_1_1_diagram.html#a92a39c2e1c44d8de08bd0eabb98867dd", null ],
    [ "setListRelationships", "class_models_1_1_diagram.html#a2bc9782c425e079357f7527967301208", null ],
    [ "diagramsAuthor", "class_models_1_1_diagram.html#a360d0d98e4934b894995906cd6f9520a", null ],
    [ "diagramsDescription", "class_models_1_1_diagram.html#a75f803e53343d9853c33a0b8fb1115e2", null ]
];