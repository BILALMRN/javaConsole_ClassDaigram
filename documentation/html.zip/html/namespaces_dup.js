var namespaces_dup =
[
    [ "Generator", "namespace_generator.html", "namespace_generator" ],
    [ "Models", "namespace_models.html", "namespace_models" ],
    [ "Views", "namespace_views.html", "namespace_views" ]
];