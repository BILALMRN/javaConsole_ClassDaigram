var dir_f8898285b3e897bc1d81fa950a148d66 =
[
    [ "RelationType.java", "_relation_type_8java.html", [
      [ "RelationType", "enum_models_1_1_enum_1_1_relation_type.html", "enum_models_1_1_enum_1_1_relation_type" ]
    ] ]
];