var dir_a4b431bec10e8bf779a89dbc80f530a2 =
[
    [ "GenerateUML.java", "_generate_u_m_l_8java.html", [
      [ "GenerateUML", "class_generator_1_1_helper_1_1_generate_u_m_l.html", null ]
    ] ],
    [ "JsonHelper.java", "_json_helper_8java.html", [
      [ "JsonHelper", "class_generator_1_1_helper_1_1_json_helper.html", null ]
    ] ]
];