var class_models_1_1_classe =
[
    [ "Classe", "class_models_1_1_classe.html#a11286c464deae88b00c1e946cc707062", null ],
    [ "Classe", "class_models_1_1_classe.html#af3718defcef739c4fcc96ce0fdc7fa57", null ],
    [ "getClassName", "class_models_1_1_classe.html#aecbb55f9291f4f92fe259b05a0047561", null ],
    [ "setClassName", "class_models_1_1_classe.html#ae5ca7013476d1f22dde70fd03c53c315", null ],
    [ "attributes", "class_models_1_1_classe.html#a1189a673959cd5afe725e0ec3baddee6", null ],
    [ "methods", "class_models_1_1_classe.html#aafbab77e231b3281c315f70228ceb132", null ]
];