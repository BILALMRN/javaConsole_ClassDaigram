var namespace_views =
[
    [ "Helper", "namespace_views_1_1_helper.html", "namespace_views_1_1_helper" ],
    [ "Project", "class_views_1_1_project.html", null ]
];