var searchData=
[
  ['generalization_203',['GENERALIZATION',['../enum_models_1_1_enum_1_1_relation_type.html#aa1c8e9a2daea3a407259f5f9c2ea43d6',1,'Models::Enum::RelationType']]]
];
