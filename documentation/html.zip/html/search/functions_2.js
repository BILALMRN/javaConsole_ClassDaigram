var searchData=
[
  ['diagram_147',['Diagram',['../class_models_1_1_diagram.html#aca0039e535074bddb897c42eb141a74a',1,'Models.Diagram.Diagram()'],['../class_models_1_1_diagram.html#a72bfb595daf6ce23951358ca6cb9054a',1,'Models.Diagram.Diagram(String diagramsName, String diagramsDescription, String diagramsAuthor, List&lt; Classe &gt; diagram)']]],
  ['diagrams_148',['Diagrams',['../class_models_1_1_diagrams.html#a81521deb708e08f8d399e2c7e0753fe0',1,'Models.Diagrams.Diagrams()'],['../class_models_1_1_diagrams.html#aa1245e7b4b3e879f28cc8368f766b87c',1,'Models.Diagrams.Diagrams(String nameProject, List&lt; Diagram &gt; diagramList)']]]
];
