var searchData=
[
  ['imgdata_172',['ImgData',['../class_models_1_1_img_data.html#aa7d2792e25819f1904f903622f47f317',1,'Models::ImgData']]]
];
