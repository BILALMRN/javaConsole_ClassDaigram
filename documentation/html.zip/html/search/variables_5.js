var searchData=
[
  ['methods_207',['methods',['../class_models_1_1_classe.html#aafbab77e231b3281c315f70228ceb132',1,'Models::Classe']]]
];
