var dir_42fc711216794489d736b0412661c8b5 =
[
    [ "Helper", "dir_cd620f3a09de929bbe78d15a733cad49.html", "dir_cd620f3a09de929bbe78d15a733cad49" ],
    [ "DataDiagram.java", "_data_diagram_8java.html", null ],
    [ "Project.java", "_project_8java.html", [
      [ "Project", "class_views_1_1_project.html", null ]
    ] ]
];