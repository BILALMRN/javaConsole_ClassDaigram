var namespace_generator_1_1_helper =
[
    [ "GenerateUML", "class_generator_1_1_helper_1_1_generate_u_m_l.html", null ],
    [ "JsonHelper", "class_generator_1_1_helper_1_1_json_helper.html", null ]
];