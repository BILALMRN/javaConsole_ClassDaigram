var annotated_dup =
[
    [ "Generator", "namespace_generator.html", [
      [ "Helper", "namespace_generator_1_1_helper.html", [
        [ "GenerateUML", "class_generator_1_1_helper_1_1_generate_u_m_l.html", null ],
        [ "JsonHelper", "class_generator_1_1_helper_1_1_json_helper.html", null ]
      ] ],
      [ "DiagramGenerator", "class_generator_1_1_diagram_generator.html", "class_generator_1_1_diagram_generator" ],
      [ "PdfGenerator", "class_generator_1_1_pdf_generator.html", null ]
    ] ],
    [ "Models", "namespace_models.html", [
      [ "Enum", "namespace_models_1_1_enum.html", [
        [ "RelationType", "enum_models_1_1_enum_1_1_relation_type.html", "enum_models_1_1_enum_1_1_relation_type" ]
      ] ],
      [ "Classe", "class_models_1_1_classe.html", "class_models_1_1_classe" ],
      [ "Diagram", "class_models_1_1_diagram.html", "class_models_1_1_diagram" ],
      [ "Diagrams", "class_models_1_1_diagrams.html", "class_models_1_1_diagrams" ],
      [ "ImgData", "class_models_1_1_img_data.html", "class_models_1_1_img_data" ],
      [ "PdfData", "class_models_1_1_pdf_data.html", "class_models_1_1_pdf_data" ],
      [ "Relationship", "class_models_1_1_relationship.html", "class_models_1_1_relationship" ]
    ] ],
    [ "Views", "namespace_views.html", [
      [ "Helper", "namespace_views_1_1_helper.html", [
        [ "FileHelper", "class_views_1_1_helper_1_1_file_helper.html", "class_views_1_1_helper_1_1_file_helper" ]
      ] ],
      [ "Project", "class_views_1_1_project.html", null ]
    ] ],
    [ "Main", "class_main.html", null ]
];