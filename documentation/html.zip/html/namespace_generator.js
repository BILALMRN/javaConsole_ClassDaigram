var namespace_generator =
[
    [ "Helper", "namespace_generator_1_1_helper.html", "namespace_generator_1_1_helper" ],
    [ "DiagramGenerator", "class_generator_1_1_diagram_generator.html", "class_generator_1_1_diagram_generator" ],
    [ "PdfGenerator", "class_generator_1_1_pdf_generator.html", null ]
];